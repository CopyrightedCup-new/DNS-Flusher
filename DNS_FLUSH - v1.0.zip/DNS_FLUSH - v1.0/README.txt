 <!> I am not responsable for any damage possibly made by this program, ues at your own risk. <!>
1. To install this "program" you need to put it in a known file location like: "C:\Program Files (x86)"

2. Create a shortcut of the batch file on your desktop. You then have almost instant access to flushing
   you DNS which makes your connection faster. Very uesfull when you are streaming or downloading.

3. Check out my channel on YouTube: https://www.youtube.com/channel/UClKSKt3qQHKRql-IcGcdVwQ
